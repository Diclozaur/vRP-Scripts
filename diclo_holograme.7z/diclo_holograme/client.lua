HologramaStatusNume = 0
HologramaNume = "Bun venit pe ~b~Drip ~w~Romania"

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(2000)
        if(HologramaStatusNume == 0)then
            HologramaNume = "Bun venit pe ~w~Drip ~b~Romania"
            HologramaStatusNume = 1
        elseif(HologramaStatusNume == 1)then
            HologramaNume = "Bun venit pe ~b~Drip ~w~Romania"
            HologramaStatusNume = 2
        elseif(HologramaStatusNume == 2)then
            HologramaNume = "Bun venit pe ~w~Drip ~b~Romania"
            HologramaStatusNume = 0
        end
    end
end)

HologramaStatusDiscord = 0
HologramaDiscord = "Discord: ~b~discord.gg/~w~link"

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(2000)
        if(HologramaStatusDiscord == 0)then
            HologramaDiscord = "Discord: ~w~discord.gg/~b~link"
            HologramaStatusDiscord = 1
        elseif(HologramaStatusDiscord == 1)then
            HologramaDiscord = "Discord: ~b~discord.gg/~w~link"
            HologramaStatusDiscord = 2
        elseif(HologramaStatusDiscord == 2)then
            HologramaDiscord = "Discord: ~w~discord.gg/~b~link"
            HologramaStatusDiscord = 0
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(1)
        Draw3DText( 6.7339558601379,-710.66436767578,45.97306060791  -1.7, HologramaNume, 0.065, 0.065) 
        Draw3DText( 6.7339558601379,-710.66436767578,45.97306060791  -1.85, HologramaDiscord, 0.06, 0.06)  
    end
end)

function Draw3DText(x,y,z,textInput,scaleX,scaleY)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)    
    local scale = (1/dist)*20
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov   
    SetTextScale(scaleX*scale, scaleY*scale)
    SetTextFont(7)
    SetTextProportional(1)
    SetTextColour(250, 250, 250, 255)		-- You can change the text color here
    SetTextDropshadow(1, 1, 1, 1, 255)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(textInput)
    SetDrawOrigin(x,y,z+2, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end